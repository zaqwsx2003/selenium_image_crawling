#cd selenium 
#python google.py 실행
#추후 파일에 자동 저장 


#설치한 selenium 불러온 코드
from selenium import webdriver
from selenium.webdriver.common.keys import Keys 
import time #시간 지연 시키는 코드
import urllib.request

driver = webdriver.Chrome() #크롬 드라이버로 실행
driver.get("https://www.google.co.kr/imghp?hl=ko&tab=wi&authuser=0&ogbl") #크롬 이미지 검색 주소  
elem = driver.find_element_by_name("q") #특정요소 찾는 코드 {find_element}
elem.send_keys("라이언")#검색 내용 {원하는 값}
elem.send_keys(Keys.RETURN)#검색 창 엔터 
SCROLL_PAUSE_TIME = 1 #로딩 대기 시간 1초
# 사이트의 스크롤 높이 확인
last_height = driver.execute_script("return document.body.scrollHeight")
while True:
    # 스크롤을 자동으로 아래로 내리기
    driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
    # 페이지의 로딩 기다리기 
    time.sleep(SCROLL_PAUSE_TIME)
    # 새 페이지의 높이를 계산 그리고 새페이지의 스크롤 높이와 비교 
    new_height = driver.execute_script("return document.body.scrollHeight")
    if new_height == last_height: #last_height가 같다면 사진이 끝남
        try:
            driver.find_element_by_css_selector(".mye4qd").click()#이미지 {class]이름 클릭
        except:
            break
    last_height = new_height

images = driver.find_elements_by_css_selector(".rg_i.Q4LuWd")
count = 1
for image in images:
    try:
        image.click()
        time.sleep(3) #로딩하는 대기 시간 3초 설정 
        imgUrl = driver.find_element_by_xpath('/html/body/div[2]/c-wiz/div[3]/div[2]/div[3]/div/div/div[3]/div[2]/c-wiz/div[1]/div[1]/div/div[2]/a/img').get_attribute("src")
        opener=urllib.request.build_opener()
        opener.addheaders=[('User-Agent','Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/36.0.1941.0 Safari/537.36')]
        urllib.request.install_opener(opener)
        urllib.request.urlretrieve(imgUrl, str(count) + ".jpg")
        count = count + 1
    except:
        pass

driver.close()